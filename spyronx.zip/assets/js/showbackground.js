// const toggleBtn = document.getElementById("toggleBtn");
// const bodyChildren = [...document.body.children].filter(
//     el => el.id !== "toggleBtn" && el.id !== "musicBtn"
// );

// let hidden = false;

// toggleBtn.addEventListener("click", () => {
//     hidden = !hidden;
//     bodyChildren.forEach(el => {
//         el.classList.toggle("hide-all", hidden);
//     });


//     toggleBtn.textContent = hidden ? "Show View" : "Toggle View";
// });


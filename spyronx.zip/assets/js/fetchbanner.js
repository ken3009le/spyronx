// assets/js/fetchbanner.js
//fetch('assets/banner/banner.txt')
//   .then(res => {
//     if (!res.ok) throw new Error("HTTP status " + res.status);
//     return res.text();
//   })
//   .then(text => {
//     document.getElementById('banner').textContent = text;
//   })
//   .catch(err => console.error("Không thể tải banner.txt:", err));
